package com.company;


public class Main {

    public static void main(String[] args) {

        int []MyintArray = new int[10];
        for(int i = 0; i<MyintArray.length; i++){
            MyintArray[i] = i * 10;
        }
        printArray(MyintArray);

       //  int []IntArray =  {1,2,3,4,5,6,7,9,9};
       //  for(int i = 0; i< IntArray.length; i++){
       //      System.out.println("Array Element "+IntArray[i]);
      //   }
        //int[] IntArray = new int[10];
       // IntArray [5]=50;
       // System.out.println("Element in "+IntArray[5]);
    }

    public static void printArray(int [] Array){
        for(int i = 0; i<Array.length; i++ ){
                System.out.println("Element "+i+" value is "+Array[i]);

        }
    }
}
