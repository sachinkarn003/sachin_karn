package com.company;

public class Pig extends Animal {
    public void animal_sound(){
        // The body of sound provided here
        System.out.println("The pig says: Wee wee.. ");
    }
}
