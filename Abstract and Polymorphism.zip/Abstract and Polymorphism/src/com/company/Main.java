package com.company;

public class Main {

    public static void main(String[] args) {
      //  Animal myObj; = new Animal(); will generate an error
     Pig mypig = new Pig();
     mypig.animal_sound();
    mypig.sound();
    }
}
