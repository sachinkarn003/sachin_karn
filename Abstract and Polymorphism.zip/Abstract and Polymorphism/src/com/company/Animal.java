package com.company;

public abstract class Animal {
    //abstract class doesn't have body
    public abstract void animal_sound();

    //another method
    public void sound(){
        System.out.println("Zzz..");
    }
}
